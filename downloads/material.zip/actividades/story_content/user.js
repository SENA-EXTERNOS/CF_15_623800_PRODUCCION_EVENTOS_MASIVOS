function ExecuteScript(strId)
{
  switch (strId)
  {
      case "68r3B5t9gqY":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

